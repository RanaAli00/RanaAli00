package com.example.mynotes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mynotes.DbHelper.DbHelper;

public class UpdateActivity extends AppCompatActivity {
    
    ImageView btnCrossUpdate;
    AppCompatButton btnSaveUpdate;
    EditText etUpdateNoteTitle, etUpdateNoteMessage;
    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        
        btnCrossUpdate = findViewById(R.id.btnCrossUpdate);
        btnSaveUpdate = findViewById(R.id.btnsaveUpdate);
        etUpdateNoteTitle = findViewById(R.id.etUpdateNoteTitle);
        etUpdateNoteMessage = findViewById(R.id.etUpdateNoteMessage);
      DbHelper  dbHelper = DbHelper.getInstance(UpdateActivity.this);
        
        // get data from intent
        String id = getIntent().getStringExtra("id");
        String title = getIntent().getStringExtra("title");
        String message = getIntent().getStringExtra("message");
        
        etUpdateNoteTitle.setText(title);
        etUpdateNoteMessage.setText(message);
        
        btnCrossUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        
        btnSaveUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = etUpdateNoteTitle.getText().toString().trim();
                String message = etUpdateNoteMessage.getText().toString().trim();
                
                dbHelper.updateNewNote(id, title, message);
                
                etUpdateNoteTitle.setText(null);
                etUpdateNoteMessage.setText(null);
                
                startActivity(new Intent(UpdateActivity.this, MainActivity.class));

                Toast.makeText(UpdateActivity.this, "Update Successfully", Toast.LENGTH_SHORT).show();
            }
        });
        
    }
}