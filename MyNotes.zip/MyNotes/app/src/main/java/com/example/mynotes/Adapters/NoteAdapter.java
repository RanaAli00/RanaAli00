package com.example.mynotes.Adapters;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mynotes.Models.Notes;
import com.example.mynotes.R;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.MyViewHolder>{

    ArrayList<Notes> notesList;
    public NoteAdapter(ArrayList<Notes> notesList) {
        this.notesList = notesList;
    }

    onCardClickListener onCardClickListener;
    public void setOnCardClickListener(NoteAdapter.onCardClickListener onCardClickListener) {
        this.onCardClickListener = onCardClickListener;
    }

    onCardLongClickListener onCardLongClickListener;
    public void setOnCardLongClickListener(NoteAdapter.onCardLongClickListener onCardLongClickListener) {
        this.onCardLongClickListener = onCardLongClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rootView = LayoutInflater.from(parent.getContext()).inflate(R.layout.notes_item_view, parent, false);
        return new MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tvNoteTitle.setText(notesList.get(position).getTitle());
        holder.tvNoteMessage.setText(notesList.get(position).getMessage());
    }

    @Override
    public int getItemCount() {
        return notesList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tvNoteTitle, tvNoteMessage;
        CardView itemCard;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNoteTitle = itemView.findViewById(R.id.tv_noteTitle);
            tvNoteMessage = itemView.findViewById(R.id.tv_noteMessage);
            itemCard = itemView.findViewById(R.id.itemCard);

            itemCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onCardClickListener != null){
                        onCardClickListener.onCardClick(itemCard, getAdapterPosition());
                    }
                }
            });
            itemCard.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (onCardLongClickListener != null){
                        onCardLongClickListener.onCardLongClick(itemCard, getAdapterPosition());
                    }
                    return true;
                }
            });

        }
    }

    public interface onCardClickListener{
        void onCardClick(CardView cardView, int position);
    }

    public interface onCardLongClickListener{
        void onCardLongClick(CardView cardView, int position);
    }

}
