package com.example.mynotes.DbHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.mynotes.Models.Notes;

import java.security.spec.ECField;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class DbHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Notes";
    public static final int DATABASE_VERSION = 1;

    private static DbHelper instance;
    public static DbHelper getInstance(Context context) {
        if (instance == null){
            instance = new DbHelper(context);
        }
        return instance;
    }

    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Notes.CREATE_TABLE_ADD_NOTES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion){
            db.execSQL(Notes.DROP_TABLE_ADD_NOTES);
            db.execSQL(Notes.CREATE_TABLE_ADD_NOTES);
        }
    }

    // CRUD Methods for ADD-NOTES-TABLE
    public boolean insertNewNote(String title, String message){
        SQLiteDatabase database = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Notes.KEY_TITLE, title);
        values.put(Notes.KEY_MESSAGE, message);

        long effectRows = 0;
        try {
            effectRows = database.insert(Notes.TABLE_ADD_NOTES, null, values);
        }
        catch (Exception ex){
            return false;
        }
        return effectRows == 1;
    }

    public boolean updateNewNote(String id, String title, String message){
        SQLiteDatabase database = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Notes.KEY_ID, id);
        values.put(Notes.KEY_TITLE, title);
        values.put(Notes.KEY_MESSAGE, message);

        long effectRows = 0;
        try {
            effectRows = database.update(Notes.TABLE_ADD_NOTES, values, Notes.KEY_ID+" = ?", new String[]{id});
        } catch (Exception ex) {
            return false;
        }
        return effectRows == 1;
    }

    public boolean deleteNewNote(String id){
        SQLiteDatabase database = getWritableDatabase();

        long effectRows = 0;
        try {
            effectRows = database.delete(Notes.TABLE_ADD_NOTES, Notes.KEY_ID+" = ?", new String[]{id});
        } catch (Exception ex) {
            return false;
        }
        return effectRows == 1;
    }

    public ArrayList<Notes> fetchNewNotes(){
        SQLiteDatabase database = getReadableDatabase();

        Cursor cursor = database.rawQuery(Notes.SELECT_TABLE_ADD_NOTES, null);

        ArrayList<Notes> notesList = new ArrayList<>(cursor.getCount());

        if (cursor.moveToFirst()){
            do {
                Notes notes = new Notes();
                notes.setId(cursor.getString(cursor.getColumnIndex(Notes.KEY_ID)));
                notes.setTitle(cursor.getString(cursor.getColumnIndex(Notes.KEY_TITLE)));
                notes.setMessage(cursor.getString(cursor.getColumnIndex(Notes.KEY_MESSAGE)));
                notesList.add(notes);
            } while (cursor.moveToNext());
        }
        return notesList;
    }

}
