package com.example.mynotes.Models;


import java.security.PublicKey;

public class Notes {

    String id;
    String title;
    String message;

    // table column
    public static final String KEY_ID = "id";
    public static final String KEY_TITLE = "title";
    public static final String KEY_MESSAGE = "message";

    // add notes table
    public static final String TABLE_ADD_NOTES = "AddNotes";
    public static final String CREATE_TABLE_ADD_NOTES = String.format("CREATE TABLE IF NOT EXISTS %S (%s INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT, %s TEXT)", TABLE_ADD_NOTES, KEY_ID, KEY_TITLE, KEY_MESSAGE);
    public static final String DROP_TABLE_ADD_NOTES = "DROP TABLE IF EXISTS " + TABLE_ADD_NOTES;
    public static final String SELECT_TABLE_ADD_NOTES = "SELECT * FROM " + TABLE_ADD_NOTES;

    // class constructor

    public Notes() {
    }

    public Notes(String title, String message) {
        this.title = title;
        this.message = message;
    }

    public Notes(String id, String title, String message) {
        this.id = id;
        this.title = title;
        this.message = message;
    }

    // class getter and setter method

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
