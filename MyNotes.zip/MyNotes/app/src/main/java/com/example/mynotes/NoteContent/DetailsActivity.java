package com.example.mynotes.NoteContent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mynotes.R;

public class DetailsActivity extends AppCompatActivity {

    TextView tvDetailNoteTitle, tvDetailNoteMessage;
    ImageView btnCrossDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        btnCrossDetail = findViewById(R.id.btnCrossDetail);
        tvDetailNoteTitle = findViewById(R.id.tvdetailNoteTitle);
        tvDetailNoteMessage = findViewById(R.id.tvDetailNoteMessage);

        btnCrossDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        // get data from intent activity
        String title = getIntent().getStringExtra("title");
        String message = getIntent().getStringExtra("message");

        tvDetailNoteTitle.setText(title);
        tvDetailNoteMessage.setText(message);

    }
}