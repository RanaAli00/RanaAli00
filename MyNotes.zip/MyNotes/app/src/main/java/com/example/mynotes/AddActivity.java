package com.example.mynotes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mynotes.DbHelper.DbHelper;

public class AddActivity extends AppCompatActivity {

    ImageView btnCross;
    AppCompatButton btnSaveNote;
    EditText etNoteTitle, etNoteMessage;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // call method to find all ids
        initViews();

        btnCross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btnSaveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = etNoteTitle.getText().toString().trim();
                String message = etNoteMessage.getText().toString().trim();
                if (title.isEmpty() && message.isEmpty()){
                    Toast.makeText(AddActivity.this, "Please Enter Note to Save", Toast.LENGTH_SHORT).show();
                }
                else {
                    // add new note to sqlite table
                    dbHelper.insertNewNote(title, message);
                    etNoteTitle.setText("");
                    etNoteMessage.setText("");
                    startActivity(new Intent(AddActivity.this, MainActivity.class));
                }
            }
        });

    }

    // find all the values of ids
    void initViews(){
        btnCross = findViewById(R.id.btnCross);
        btnSaveNote = findViewById(R.id.btnSaveNoteMessage);
        etNoteTitle = findViewById(R.id.etNoteTitle);
        etNoteMessage = findViewById(R.id.etNoteMessage);
        dbHelper = DbHelper.getInstance(AddActivity.this);
    }


}