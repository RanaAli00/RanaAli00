package com.example.mynotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.mynotes.Adapters.NoteAdapter;
import com.example.mynotes.DbHelper.DbHelper;
import com.example.mynotes.Models.Notes;
import com.example.mynotes.NoteContent.DetailsActivity;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    MaterialButton btnAdd;
    RecyclerView recyclerView;
    NoteAdapter noteAdapter;
    DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // set the custom Tool-Bar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,AddActivity.class);
                startActivity(intent);
            }
        });

        // fetch data list from sqlite table
        dbHelper = DbHelper.getInstance(MainActivity.this);
        ArrayList<Notes> dataList = dbHelper.fetchNewNotes();

        // set adapter to the recycler view
        recyclerView = findViewById(R.id.recyclerView);
        noteAdapter = new NoteAdapter(dataList);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(noteAdapter);

        // set the adapter click listener
        noteAdapter.setOnCardClickListener(new NoteAdapter.onCardClickListener() {
            @Override
            public void onCardClick(CardView cardView, int position) {
                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                intent.putExtra("title", dataList.get(position).getTitle());
                intent.putExtra("message", dataList.get(position).getMessage());
                startActivity(intent);
            }
        });
        noteAdapter.setOnCardLongClickListener(new NoteAdapter.onCardLongClickListener() {
            @Override
            public void onCardLongClick(CardView cardView, int position) {
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, cardView);
                popupMenu.inflate(R.menu.item_menu);

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        int id = item.getItemId();
                        if (id == R.id.itemOpt_update){
                            Intent intent = new Intent(MainActivity.this, UpdateActivity.class);
                            intent.putExtra("id", String.valueOf(dataList.get(position).getId()));
                            intent.putExtra("title", String.valueOf(dataList.get(position).getTitle()));
                            intent.putExtra("message", String.valueOf(dataList.get(position).getMessage()));
                            startActivity(intent);
                        }
                        else if (id == R.id.itemOpt_share){
                            shareNote(dataList.get(position).getTitle(), dataList.get(position).getMessage());
                        }
                        else if (id == R.id.itemOpt_delete){
                            dbHelper.deleteNewNote(dataList.get(position).getId());
                            dataList.remove(position);
                            noteAdapter.notifyItemRemoved(position);
                            noteAdapter.notifyDataSetChanged();
                        }
                        return true;
                    }
                });

                popupMenu.show();
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.opt_selectAll){

        }
        else if (id == R.id.opt_ascendingOrder){

        }
        else if (id == R.id.opt_descendingOrder){

        }
        else if (id == R.id.opt_exit){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    void shareNote(String title, String message){
        String textToShare = title+"\n"+message;
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, textToShare);

        startActivity(Intent.createChooser(shareIntent, "Share via"));
    }
}